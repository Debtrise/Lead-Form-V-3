import Container from '@mui/material/Container'; 
import Grid from '@mui/material/Grid'; 
import Box from '@mui/material/Box'; 
import Typography from '@mui/material/Typography';

import Head from 'next/head';

import styles from '@/styles/header.module.css'

import Image from 'next/image';

import logo from '@/images/debtrise_logo.png';

import Link from 'next/link';

import IconButton from '@mui/material/IconButton';
import PhoneIcon from '@mui/icons-material/Phone';

export default function Header() {
  return (
    <div className={styles.main}>
      <Container>
        <div className={styles.inner}>
          <Head>
            <title>Debtrise</title>
          </Head>
          <Grid container spacing={2} alignItems='center'>
            <Grid className={styles.grid} item={true}  xs={6}>
              <div className={styles.imageWrapper}>
                <Link href={'Https://Debtrise.com/Home”'} className={styles.imageWrapper}>
                  <Image
                    priority
                    src={logo}
                    alt="Achieve Logo"
                    className={styles.logoImage}
                  />
                </Link>
              </div>
          
            </Grid>
            <Grid className={styles.contactContainer} item={true} xs={6} justifyContent='flex-end'>
                <Box mr={1}>
                  <IconButton onClick={() => window.location.href = `tel:(949) 832-7907`}>
                    <PhoneIcon />
                  </IconButton>
                </Box>
                <Typography variant='subtitle2' align='right'  display={{ xs: 'none' }}>(949) 832-7907</Typography>
            </Grid>
          </Grid>
        </div>
      </Container>
    </div>
  )
}
