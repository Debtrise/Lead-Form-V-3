import Container from '@mui/material/Container'; 
import Stack from '@mui/material/Stack'; 
import Grid from '@mui/material/Grid'; 
import { Typography } from '@mui/material';

import styles from '@/styles/footer.module.css'

import Link from 'next/link';

export default function Footer() {
  return (
    <div className={styles.main}>
      <Container>
        <Grid container spacing={2} justifyContent='center'>
          <Grid item={true}>
            <Link href={'Https://Debtrise.com/Privacy'}>
              <Typography className={styles.footerLinkText} variant='subtitle2'>Privacy Policy</Typography>
            </Link>
          </Grid>
          <Grid item={true}>
            <Link href={'Https://Debtrise.com/Terms'}>
              <Typography className={styles.footerLinkText} variant='subtitle2'>Terms of Use</Typography>
            </Link>
          </Grid>
          <Grid item={true}>
            <Link href={'Https://Debtrise.com/Contact'}>
              <Typography className={styles.footerLinkText} variant='subtitle2'>Contact Us</Typography>
            </Link>
          </Grid>
        </Grid>
        <Stack className={styles.termsContainer} spacing={1}>
          {/* <Typography variant='body2'>
            The financial solutions for which you will be evaluated are offered by service providers with which we are affiliated
            and/or compensated by who participates on our website. Terms and conditions apply to each, 
            and not all are available in every state.
          </Typography>

          <Typography variant='body2'>
            Achieve.com, a d/b/a of Bills.com, LLC (NMLS ID #138464) operates as a marketing lead generator for affiliates
            and non-affiliates, and as a broker for loans and debt resolution services offered by its affiliates.
            We also offer certain mobile applications that allow consumers to view and analyze their finances.
            We may take applications for our affiliates, but we do not make credit decisions, originate loans,
            process consumer loan or bill payments, or provide any other financial services.
            We do not collect any fees or other compensation from consumers.
          </Typography>

          <Typography variant='body2'>
            <strong>Personal loans</strong> are available through our affiliate Achieve Personal Loans (NMLS ID #227977), originated by Cross River Bank, a New Jersey State Chartered Commercial Bank or Pathward , N.A., Equal Housing Lenders and may not be available in all states. All loan and rate terms are subject to eligibility restrictions, application review, credit score, loan amount, loan term, lender approval, credit usage and history. Loans are not available to residents of all states. Minimum loan amounts vary due to state specific legal restrictions. Loan amounts generally range from $5,000 to $50,000 (including the origination fee) and are offered based on underwriting conditions and loan purpose. APRs range from 7.99 to 29.99% and include applicable origination fees. Repayment periods range from 24 to 60 months. For example: A four-year $20,000 loan with an APR of 18.34% would have an estimated monthly payment of $561.60 and total cost of $26,956.80. To qualify for a 7.99% APR loan, a borrower will need excellent credit, a loan amount of $12,000.00 or less, and a term of 24 months. Loan origination fees vary from 1.99% to 6.99%. Adding a co-borrower with sufficient income; using at least eighty-five percent (85%) of the loan proceeds to pay off qualifying existing debt directly; or showing proof of sufficient retirement savings, could help you also qualify for a lower rate. Average interest savings for personal loans range from 0% - 6% based on closed loans that qualified for one or more of our rate discounts in July 2022. † Funding time periods are estimates and can vary for each loan request Same day decisions assume a completed application with all required supporting documentation submitted early enough on a day that our offices are open. Business hours are Monday-Friday 6am-8pm MST, and Saturday-Sunday 7am-4pm MST.
          </Typography>

          <Typography variant='body2'>
            <strong>Home Equity loans</strong> are available through our affiliate Achieve Loans (NMLS ID #1810501). All loan requests are subject to eligibility requirements, application review, loan amount, loan term and lender approval. Product terms are subject to change at any time. Home loans are a line of credit. Loans are not available to residents of all states and available loan terms/fees may vary by state where offered. Line amounts are between $15,000 and $150,000 and are assigned based on debt to income and loan to home value. Minimum 600 credit score applies for debt consolidation requests, minimum 670 applies to cash out requests. Other conditions apply. Fixed rate APRs range from 10.25% - 16.00% and are assigned based on underwriting requirements and automatic payment enrollment (autopay enrollment is not a condition of loan approval). Example: average HELOC is $57,150 with an APR of 12.75% and estimated monthly payment of $951 for a 15-year loan. 10 and 15 year terms available. Both terms have a 5 year draw period. Payments are fully amortized during each period and determined on the outstanding principal balance each month. Closing fees range from $750 to $6,685, depending on line amount and state law requirements and typically include origination (2.5% of line amount) and underwriting ($685) fees if allowed by law. Average funding time is between 15 to 18 days from submitted application and documentation. Property must be owner-occupied and combined loan to value may not exceed 80%, including the new loan request. Property insurance is required and flood insurance may be required if the subject property is located in a flood zone. You must pledge your home as collateral and could lose your home if you fail to repay. Contact Achieve Loans for further details. We could beat your personal loan rate by 50%: Claim is based on loan rates of 24%+ and 10-year loan through Achieve Loans.
          </Typography>

          <Typography variant='body2'>
            <strong>Affiliated Business Arrangement Disclosure:</strong> Achieve.com, a d/b/a of Bills.com, LLC (“Achieve.com”) (NMLS #138464), is a wholly-owned subsidiary of Freedom Financial Network Funding, LLC (“FFNF”). FFNF also owns 99% of Lendage, LLC (“Achieve Loans”). Because of this relationship, your referral to Achieve Loans may provide Achieve.com a financial or other benefit. Where permitted by applicable state law, Achieve Loans charges: 1) an origination fee of 2.50%, and 2) an underwriting fee of $685. You are NOT required to use Achieve Loans for a home equity line of credit. Please click here for the full Affiliated Business Arrangement disclosure form.
          </Typography>

          <Typography variant='body2'>
            <strong>Other debt solutions</strong> are available through our affiliate Freedom Resolution (NMLS ID # 1248929). Freedom Resolution does not assume your debts, make monthly payments to creditors or provide tax, bankruptcy, accounting or legal advice or credit repair services. Its service is not available in all states, including New Jersey, and its fees may vary from state to state.
          </Typography>

          <Typography variant='body2'>
            One monthly payment - Solutions offered may or may not consolidate all debt into one monthly payment, each situation varies based on individual circumstances.
          </Typography>

          <Typography variant='body2'>
            $800+/month/ nearly $10,000/year savings: Claim is based on average monthly debt savings from Achieve Loans HELOC originated loans for 2021. Monthly savings will vary based on each loan situation and can be more or less than $800.
          </Typography>

          <Typography variant='body2'>
            <strong>Fair Credit Ok:</strong> Minimum 600 credit score applies to home loan debt consolidation requests and minimum 620 applies to personal loan requests.
          </Typography> */}
          
          <Typography variant='body2' textAlign='center'>© 2023 Debtrice.com, All rights reserved.</Typography>
        </Stack>
      </Container>
    </div>
  )
}
