import Grid from '@mui/material/Grid'; 

import styles from '@/styles/progress.module.css'

export default function Progress({ step = 1 }) {

  return (
    <Grid container className={styles.progressContainer} spacing={2} mt={1}>
      <Grid className={styles.progressItem} item={true}  xs={4}>
        <div className={[ step >= 1 ? styles.progressItemInnerActive : styles.progressItemInner]} />
      </Grid>
      <Grid className={styles.progressItem} item={true}  xs={4}>
        <div className={[ step >= 2 ? styles.progressItemInnerActive : styles.progressItemInner]} />
      </Grid>
      <Grid className={styles.progressItem} item={true}  xs={4}>
        <div className={[ step >= 3 ? styles.progressItemInnerActive : styles.progressItemInner]} />
      </Grid>
    </Grid>
  )
}
