import { createContext, useContext, useState } from "react";

const Context = createContext();

export function DebtProvider({ children }) {

  const [amount, setAmount] = useState(20000);

  const [state, setState] = useState('AK');
  
  return (
    <Context.Provider value={
      { 
        amountContext: [amount, setAmount],
        stateContext: [state, setState],
      }
    }>
      {children}
    </Context.Provider>
  );
}

export function useDebtContext() {
  return useContext(Context);
}