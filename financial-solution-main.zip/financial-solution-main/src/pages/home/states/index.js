import React, { useState } from 'react';

import Box from '@mui/material/Box'; 

import Grid from '@mui/material/Grid'; 

import styles from '@/styles/home.module.css'

import Progress from '@/components/progress';

import { Typography } from '@mui/material';

import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';

import LoadingButton from '@mui/lab/LoadingButton';

import { useRouter } from 'next/router'

import stateList from '@/static/stateList';

import { useDebtContext } from "@/context/debt";

export default function Home() {
  const router = useRouter()

  const { stateContext } = useDebtContext();

  const [ state, setState ] = stateContext;
  const [loading, setLoading] = useState(false);

  const handleStateChange = (event) => {
    setState(event.target.value);
  };

  const _onContinue = () => {
    setLoading(true);

    setTimeout(() => {
      router.push('/home/contact-info')
      setLoading(false);
    }, 2000);
  }

  return (
    <main className={styles.main}>
      <Box className={styles.inner}>
        <Progress step={1} />
        <Typography className={styles.chooseDebtText} variant='h5' align='center' mt={4}>What state do you live in?</Typography>

        <Box className={styles.stateContainer} mt={5}>
          <FormControl fullWidth>
            <InputLabel>State</InputLabel>
            <Select
              value={state}
              label="State"
              onChange={handleStateChange}
            >
              {stateList.map((s) => {
                const stateName = s.name[0].toUpperCase() + s.name.slice(1).toLowerCase();
                return <MenuItem key={s.value} value={s.value}>{stateName}</MenuItem>
              })}
            </Select>
          </FormControl>
        </Box>
        
        <Grid mt={5} container justifyContent="center">
          <LoadingButton className={styles.continueButton} variant="contained" loading={loading} onClick={_onContinue}>
            Next
          </LoadingButton>
        </Grid>
      
      </Box>
    </main>
  )
}
