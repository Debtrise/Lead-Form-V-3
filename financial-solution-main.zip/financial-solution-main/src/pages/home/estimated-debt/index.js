import React, { useState } from 'react';

import Box from '@mui/material/Box'; 

import Grid from '@mui/material/Grid'; 

import styles from '@/styles/home.module.css'

import Progress from '@/components/progress';

import { Typography } from '@mui/material';

import Slider from '@mui/material/Slider';

import LoadingButton from '@mui/lab/LoadingButton';

import { useRouter } from 'next/router'

import { useDebtContext } from "@/context/debt";

export default function Home() {
  const router = useRouter()

  const { amountContext } = useDebtContext();

  const [ amount, setAmount ] = amountContext;
  const [loading, setLoading] = useState(false);

  const marks = [
    {
      value: 1000,
      label: '$1,000',
    },
    {
      value: 100000,
      label: '$100,000+',
    }
  ];

  const handleSliderChange = (event, newValue) => {
    setAmount(newValue);
  };

  const _onContinue = () => {
    setLoading(true);

    setTimeout(() => {
      router.push('/home/states')
      setLoading(false);
    }, 2000);
 
  }

  return (
    <main className={styles.main}>
      <Box className={styles.inner}>
        <Progress step={1} />
        <Box className={styles.headerTextContainer}>
          <Typography variant='h5' align='center' mt={4}>Choose your debt amount</Typography>
        </Box>
       
        <Typography variant='h3' className={styles.debtAmountText} align='center' mt={4}>${amount.toLocaleString("us-EN")}</Typography>
        <Grid className={styles.sliderContainer} mt={3} justifyContent="center">
          <Slider
            defaultValue={20000}
            min={1000}
            max={100000}
            step={1000}
            marks={marks}
            onChange={handleSliderChange}
          />
        </Grid>
        <Grid mt={5} container justifyContent="center">
          <LoadingButton className={styles.continueButton} variant="contained" loading={loading} onClick={_onContinue}>
            Continue
          </LoadingButton>
        </Grid>
      
      </Box>
    </main>
  )
}
