import React, { useState, useEffect } from 'react';

import Box from '@mui/material/Box'; 

import Grid from '@mui/material/Grid'; 

import styles from '@/styles/home.module.css'

import Progress from '@/components/progress';

import { Typography } from '@mui/material';

import validator from 'validator';

import TextField from '@mui/material/TextField';

import InputMask from 'react-input-mask';

import LoadingButton from '@mui/lab/LoadingButton';

import { useRouter } from 'next/router'

import { useDebtContext } from "@/context/debt";

export default function Home() {
  const router = useRouter()

  const { amountContext, stateContext } = useDebtContext();
  const [ amount ] = amountContext;
  const [ state ] = stateContext;

  const [formValid, setFormValid] = useState(false);
  const [isInitial, setIsInitial] = useState(true);

  const [firstName, setFirstName] = useState('');
  const [firstNameValid, setFirstNameValid] = useState(false);

  const [lastName, setLastName] = useState('');
  const [lastNameValid, setLastNameValid] = useState(false);
  
  const [phone, setPhone] = useState('');
  const [phoneValid, setPhoneValid] = useState(false);

  const [email, setEmail] = useState('');
  const [emailValid, setEmailValid] = useState(false);

  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (firstNameValid && lastNameValid && phoneValid && emailValid) {
      setFormValid(true);
    } else {
      setFormValid(false);
    }
  }, [firstNameValid, lastNameValid, phoneValid, emailValid])
  
  const _onSubmitForm = async () => {
    if (formValid) {
      setLoading(true);

      const payload = {
        amount,
        state,
        firstName,
        lastName,
        phone: `+1${phone.replaceAll('-', '')}`,
        email
      }

      await fetch(
        'https://hook.us1.make.com/ra9k6y4dpbh33ue73f7o3ofpp3rr228m',
        {
        method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          redirect: 'follow',
          referrerPolicy: 'no-referrer',
          body: JSON.stringify(payload)
        }
      ).then((response) => {
        console.log(response.status);
        setTimeout(() => {
          if (response.status === 200) {
            router.push('Https://DebtRise.com/Thank-you')
          }
          setLoading(false);
        }, 2000);
      }).catch((error) => {
        console.log(error);
        setLoading(false);
      });
    } else {
      setFormValid(false);
      setIsInitial(false);
    }
  }

  return (
    <main className={styles.main}>
      <Box className={styles.formInner}>
        <Box className={styles.formPadding}>
          <Progress step={2} />
          <Typography className={styles.chooseDebtText} variant='h5' align='center' mt={4}>See your results</Typography>
        </Box>

        <Box
          component="form"
          autoComplete="off"
          pt={2}
          className={styles.contactForm}
          noValidate={false}
        >
          <Box mt={2}>
            <TextField
              label="First Name"
              variant="outlined"
              value={firstName}
              onChange={(e) => {
                setFirstName(e.target.value)
                setFirstNameValid(e.target.value && e.target.value !== '')
              }}
              error={!firstNameValid && !isInitial}
              helperText={!firstNameValid && !isInitial && 'First Name required'}
              fullWidth
            />
          </Box>

          <Box mt={2}>
            <TextField
              label="Last Name"
              variant="outlined"
              value={lastName}
              onChange={(e) => {
                setLastName(e.target.value)
                setLastNameValid(e.target.value && e.target.value !== '')
              }}
              error={!lastNameValid && !isInitial}
              helperText={!lastNameValid && !isInitial && 'Last Name required'}
              fullWidth
            />
          </Box>

          <Box mt={2}>
          <InputMask
            mask="999-999-9999"
            value={phone}
            onChange={(e) => {
              setPhone(e.target.value)
              setPhoneValid(e.target.value && e.target.value !== '' && validator.isMobilePhone(`${e.target.value}`, 'en-US'))
            }}
          >
            {() => 
              <TextField
                label="Phone"
                variant="outlined"
                error={!phoneValid && !isInitial}
                helperText={!phoneValid && !isInitial && 'Phone number is not valid'}
                fullWidth
              />
            }
          </InputMask>
            
          </Box>

          <Box mt={2}>
            <TextField
              label="Email"
              variant="outlined"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value)
                setEmailValid(e.target.value && e.target.value !== '' && /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(email));
              }}
              error={!emailValid && !isInitial}
              helperText={!emailValid && !isInitial && 'Email is not valid'}
              fullWidth
            />
          </Box>

          <Typography className={styles.consentText}  variant='body2'>
            By providing your phone number above, and clicking on
            ‘Click To See Your Results’ below, you are consenting to receive calls, texts,
            and recorded messages as described below.
          </Typography>
        </Box>
        
        
        <Grid mt={5} container justifyContent="center" className={styles.formPadding}>
          <LoadingButton
            className={styles.continueButton}
            variant="contained"
            sx={{
              height: '48px',
              borderRadius: '8px'
            }}
            loading={loading}
            onClick={_onSubmitForm}
          >
            Click to see your results
          </LoadingButton>
        </Grid>

        <Box mt={10} className={styles.consentFootContainer}>
          <Typography className={styles.consentFootText} variant='body2'>
            I consent to receive calls and text messages, including marketing and promotional messages, 
            from Debtrise.com, and its related or affiliated companies, 
            including through the use of an automatic telephone dialing system or an artificial or 
            prerecorded voice, at any telephone number I provide. Msg and data rates may apply. 
            Consent is not a condition for purchase. For text messages, reply STOP to cancel. 
            If you choose not to consent, you may call us at 949-832-7907 to continue your inquiry.
          </Typography>
        </Box>
      
      </Box>
    </main>
  )
}
