import React, { useEffect } from 'react';

import Script from 'next/script'
import { useRouter } from 'next/router'
import * as fbq from '../lib/fpixel'


import { createTheme, ThemeProvider, styled } from '@mui/material/styles';

import Header from '@/components/header'
import Footer from '@/components/footer'

import { DebtProvider } from '@/context/debt';

import '@fontsource/poppins/100.css';
import '@fontsource/poppins/200.css';
import '@fontsource/poppins/300.css';
import '@fontsource/poppins/400.css';
import '@fontsource/poppins/500.css';
import '@fontsource/poppins/600.css';
import '@fontsource/poppins/700.css';
import '@fontsource/poppins/800.css';
import '@fontsource/poppins/900.css';

import '@/styles/global.css'

const theme = createTheme({
  typography: {
    fontFamily: ['Poppins', 'sans-serif', 'serif'].join(','),
    button: {
      textTransform: 'none',
      fontSize: '18px'
    },
    subtitle2: {
      fontSize: 14,
    },
    body2: {
      fontSize: 12,
    },
    h5: {
      fontSize: 28,
      fontWeight: 500,
    },
    h3: {
      fontSize: 40,
      fontWeight: 600,
    }
  },
  palette: {
    primary: {
      main: '#36923B',
    },
  },
});

export default function App({ Component, pageProps }) {
  const router = useRouter()

  useEffect(() => {
    fbq.pageview()

    const handleRouteChange = () => {
      fbq.pageview()
    }

    router.events.on('routeChangeComplete', handleRouteChange)
    return () => {
      router.events.off('routeChangeComplete', handleRouteChange)
    }
  }, [router.events])

  return (
    <DebtProvider>
      <ThemeProvider theme={theme}>
        <Script
          id="fb-pixel"
          strategy="afterInteractive"
          dangerouslySetInnerHTML={{
            __html: `
              !function(f,b,e,v,n,t,s)
              {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
              n.callMethod.apply(n,arguments):n.queue.push(arguments)};
              if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
              n.queue=[];t=b.createElement(e);t.async=!0;
              t.src=v;s=b.getElementsByTagName(e)[0];
              s.parentNode.insertBefore(t,s)}(window, document,'script',
              'https://connect.facebook.net/en_US/fbevents.js');
              fbq('init', ${fbq.FB_PIXEL_ID});
            `,
          }}
        />
        <Header />
        <Component {...pageProps} />
        <Footer />
      </ThemeProvider>
    </DebtProvider>
  );
}